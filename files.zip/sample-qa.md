# 🧪 Sample Q&A — Groww MF FAQ Assistant

10 sample questions with the assistant's expected answers and source links.

---

## Q1: What is the expense ratio of Groww ELSS Tax Saver Fund?

**Answer:**
The Groww ELSS Tax Saver Fund has an expense ratio of approximately **0.75% for the Direct plan** and approximately **2.21% for the Regular plan** (as per AMFI data). Direct plans are always cheaper because there is no distributor commission involved.

🔗 Source: [Groww ELSS Tax Saver Fund](https://groww.in/mutual-funds/groww-elss-tax-saver-fund-direct-growth)

📅 Last updated from sources: May 2025

---

## Q2: What is the ELSS lock-in period?

**Answer:**
All ELSS (Equity Linked Savings Scheme) funds in India have a **mandatory 3-year lock-in period** as per SEBI regulations. This means you cannot redeem your investment before 3 years from the date of purchase. Each SIP installment has its own 3-year lock-in from its respective investment date.

🔗 Source: [SEBI ELSS Circular](https://www.sebi.gov.in/legal/circulars/dec-2005/amendment-to-sebi-mutual-fund-regulations_7295.html)

📅 Last updated from sources: May 2025

---

## Q3: What is the minimum SIP amount for Groww Flexi Cap Fund?

**Answer:**
The minimum SIP amount for Groww Flexi Cap Fund is **₹500 per month**. The minimum lump sum investment is ₹1000.

🔗 Source: [Groww Flexi Cap Fund](https://groww.in/mutual-funds/groww-flexi-cap-fund-direct-growth)

📅 Last updated from sources: May 2025

---

## Q4: What is the exit load for Groww Large Cap Fund?

**Answer:**
The exit load for Groww Large Cap Fund is **1% if you redeem within 1 year** from the date of allotment. After 1 year, the exit load is **NIL** (zero).

🔗 Source: [Groww Large Cap Fund](https://groww.in/mutual-funds/groww-large-cap-fund-direct-growth)

📅 Last updated from sources: May 2025

---

## Q5: How do I download my capital gains statement from Groww?

**Answer:**
To download your capital gains statement from Groww: Login to the Groww app or website → go to **Portfolio** → **Statements** → **Capital Gains Statement** → select the financial year → click **Download PDF**. Alternatively, you can download a consolidated statement from CAMS or KFintech using your registered email.

🔗 Source: [Groww Capital Gains Statement Guide](https://groww.in/blog/capital-gain-statement)

📅 Last updated from sources: May 2025

---

## Q6: What is the benchmark for Groww Nifty Total Market Index Fund?

**Answer:**
The Groww Nifty Total Market Index Fund tracks the **Nifty Total Market TRI** (Total Return Index) as its benchmark. This index covers large, mid, small, and micro-cap stocks listed on NSE — it is one of the broadest market indices in India.

🔗 Source: [Groww Nifty Total Market Index Fund](https://groww.in/mutual-funds/groww-nifty-total-market-index-fund-direct-growth)

📅 Last updated from sources: May 2025

---

## Q7: What is the riskometer level for Groww Liquid Fund?

**Answer:**
The Groww Liquid Fund has a riskometer level of **Moderate (Low to Moderate)**. Liquid funds invest in very short-term debt instruments and are generally considered lower risk than equity funds, though they are not risk-free.

🔗 Source: [Groww Liquid Fund](https://groww.in/mutual-funds/groww-liquid-fund-direct-growth)

📅 Last updated from sources: May 2025

---

## Q8: What is the exit load for Groww ELSS Tax Saver Fund?

**Answer:**
The Groww ELSS Tax Saver Fund has **NIL exit load**. This is because ELSS funds already have a mandatory 3-year lock-in period, so no additional exit load is charged.

🔗 Source: [Groww ELSS Tax Saver Fund](https://groww.in/mutual-funds/groww-elss-tax-saver-fund-direct-growth)

📅 Last updated from sources: May 2025

---

## Q9 (REFUSED — Opinion Question): Which Groww fund is best for me?

**Answer (Refusal):**
I can only share factual scheme details — I cannot recommend which fund is best for you, as that depends on your personal financial goals, risk appetite, and tax situation. For performance data, please visit the official Groww factsheet. For personalized investment decisions, please consult a SEBI-registered financial advisor.

🔗 Source: [SEBI Registered Advisors](https://www.sebi.gov.in/sebiweb/other/OtherAction.do?doRecognisedFpi=yes&intmId=13)

📅 Last updated from sources: May 2025

---

## Q10: Does ELSS give tax benefit?

**Answer:**
Yes. Investments in ELSS funds qualify for a **tax deduction of up to ₹1.5 lakh per financial year** under Section 80C of the Income Tax Act. The returns after the 3-year lock-in are treated as Long-Term Capital Gains (LTCG), taxed at 12.5% above ₹1.25 lakh.

🔗 Source: [Groww MF Taxation Guide](https://groww.in/blog/mutual-fund-taxation)

📅 Last updated from sources: May 2025

---

*All answers are factual only. No investment advice is provided. Verify all figures on official sources before investing.*
