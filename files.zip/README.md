# 🌱 Groww Mutual Fund FAQ Chatbot

A facts-only FAQ assistant for Groww AMC mutual fund schemes. Built as a single HTML file that uses the Claude AI API to answer factual questions about MF expense ratios, SIP amounts, exit loads, ELSS lock-in, riskometer, benchmarks, and how to download statements.

**⚠️ Disclaimer: This tool is for educational/factual purposes only. It does NOT provide investment advice. Always consult a SEBI-registered financial advisor before investing.**

---

## 📦 What's in this project

```
groww-faq-chatbot/
├── index.html          ← The entire chatbot (one file!)
├── sources.md          ← List of all 20 official sources used
├── sample-qa.md        ← 10 sample questions and answers
└── README.md           ← This file
```

---

## 🏦 Scope: AMC + Schemes

**AMC:** Groww Mutual Fund (formerly Indiabulls AMC)

**5 Schemes covered:**
| Scheme | Type |
|--------|------|
| Groww ELSS Tax Saver Fund | ELSS (Tax Saving) |
| Groww Large Cap Fund | Large Cap Equity |
| Groww Flexi Cap Fund | Flexi Cap Equity |
| Groww Nifty Total Market Index Fund | Index Fund |
| Groww Liquid Fund | Debt / Liquid |

---

## 🚀 How to put this on GitHub (step by step for beginners)

### Step 1 — Create a GitHub account
1. Go to **https://github.com**
2. Click **"Sign up"** and make a free account
3. Verify your email

### Step 2 — Create a new repository
1. Once logged in, click the **"+"** button in the top right corner
2. Click **"New repository"**
3. Name it: `groww-mf-faq` (no spaces, use hyphens)
4. Make sure it is set to **Public**
5. Check the box that says **"Add a README file"**
6. Click **"Create repository"**

### Step 3 — Upload your files
1. Inside your new repository, click **"Add file"** → **"Upload files"**
2. Drag and drop ALL 4 files from this folder:
   - `index.html`
   - `sources.md`
   - `sample-qa.md`
   - `README.md` (replace the existing one)
3. Scroll down and click **"Commit changes"**

### Step 4 — Turn on GitHub Pages (free website hosting!)
1. Click on **"Settings"** (tab near the top of your repository)
2. Scroll down in the left menu and click **"Pages"**
3. Under **"Source"**, click the dropdown that says **"None"**
4. Select **"main"** (or "master") branch
5. Make sure the folder is set to **"/ (root)"**
6. Click **"Save"**
7. Wait 1–2 minutes

### Step 5 — Visit your live website!
GitHub will show you a green box with your URL, something like:
```
https://YOUR-USERNAME.github.io/groww-mf-faq/
```
Open that URL in your browser — your chatbot is live! 🎉

---

## ⚙️ How the chatbot works (simple explanation)

1. You type a question in the chat box
2. The website sends it to **Claude AI** (Anthropic's AI)
3. Claude reads a built-in "rulebook" that tells it:
   - Only answer facts about 5 Groww schemes
   - Always show a source link
   - Never give investment advice
   - Refuse questions about returns or "should I buy?"
4. Claude's answer appears in the chat with a clickable source link

> **No server needed!** Everything runs in the browser. The Claude API key is handled automatically when you use this inside Claude.ai.

---

## 🔍 What questions it can answer

✅ **It WILL answer:**
- "What is the expense ratio of [scheme]?"
- "What is the exit load for [scheme]?"
- "What is the minimum SIP amount?"
- "What is the ELSS lock-in period?"
- "What is the riskometer/risk level?"
- "What benchmark does [scheme] track?"
- "How do I download my capital gains statement?"

❌ **It will REFUSE to answer:**
- "Should I invest in this fund?"
- "Which fund has better returns?"
- "What will my returns be?"
- Any personal advice questions

---

## ⚠️ Known Limitations

1. **Expense ratios change** — SEBI allows AMCs to change expense ratios. Always verify on the official Groww website or AMFI.
2. **Only 5 schemes** — Does not cover all Groww funds, only the 5 listed above.
3. **No real-time NAV** — Does not show live NAV prices or performance data.
4. **No personal account access** — Cannot check YOUR portfolio, SIP status, or transactions.
5. **Needs internet** — Must be online to use the Claude AI API.
6. **No PII** — Do NOT type your PAN, Aadhaar, phone number, or OTP into this chatbot.

---

## 📚 Sources used

See `sources.md` for all 20 official URLs.

Main sources:
- [Groww.in](https://groww.in/mutual-funds) — Scheme pages, factsheets
- [AMFI India](https://www.amfiindia.com) — Expense ratios, scheme data
- [SEBI](https://www.sebi.gov.in) — Regulations, riskometer
- [CAMS Online](https://www.camsonline.com) — Statement downloads
- [KFintech](https://www.kfintech.com) — Consolidated statements

---

## 🛡️ Disclaimer

This chatbot provides **factual information only** from public sources. It does **not** provide investment advice, portfolio recommendations, or return projections. Past performance of mutual funds does not guarantee future results. Mutual fund investments are subject to market risks. Please read all scheme-related documents carefully before investing. Consult a SEBI-registered investment advisor for personalized advice.

SEBI Investor Helpline: 1800-266-7575 | AMFI: www.amfiindia.com
