# 📋 Sources List — Groww MF FAQ Chatbot

All sources are official public pages from AMC, AMFI, SEBI, or CAMS/KFintech.
No third-party blogs or screenshots used.

| # | Source Name | URL | Used For |
|---|-------------|-----|----------|
| 1 | Groww ELSS Tax Saver Fund | https://groww.in/mutual-funds/groww-elss-tax-saver-fund-direct-growth | Expense ratio, exit load, SIP minimum, benchmark |
| 2 | Groww Large Cap Fund | https://groww.in/mutual-funds/groww-large-cap-fund-direct-growth | Expense ratio, exit load, SIP minimum, benchmark |
| 3 | Groww Flexi Cap Fund | https://groww.in/mutual-funds/groww-flexi-cap-fund-direct-growth | Expense ratio, exit load, SIP minimum, benchmark |
| 4 | Groww Nifty Total Market Index Fund | https://groww.in/mutual-funds/groww-nifty-total-market-index-fund-direct-growth | Expense ratio, benchmark, tracking error |
| 5 | Groww Liquid Fund | https://groww.in/mutual-funds/groww-liquid-fund-direct-growth | Expense ratio, exit load (graded), riskometer |
| 6 | AMFI Scheme Details Page | https://www.amfiindia.com/research-information/other-data/scheme-details | Scheme codes, ISIN, plan types |
| 7 | AMFI Expense Ratio Explanation | https://www.amfiindia.com/investor-corner/knowledge-center/expense-ratio.html | Expense ratio definition, TER explanation |
| 8 | AMFI ELSS Funds List | https://www.amfiindia.com/research-information/aum-data/scheme-wise-aum | ELSS category details |
| 9 | SEBI ELSS Lock-in Circular | https://www.sebi.gov.in/legal/circulars/dec-2005/amendment-to-sebi-mutual-fund-regulations_7295.html | 3-year lock-in mandate for ELSS |
| 10 | SEBI Riskometer Guidelines | https://www.sebi.gov.in/legal/circulars/oct-2020/product-labeling-in-mutual-fund-schemes-risk-o-meter_47948.html | Riskometer levels definition |
| 11 | SEBI Categorization Circular | https://www.sebi.gov.in/legal/circulars/oct-2017/categorization-and-rationalization-of-mutual-fund-schemes_36199.html | Large cap / Flexi cap / ELSS definitions |
| 12 | SEBI Total Expense Ratio Circular | https://www.sebi.gov.in/legal/circulars/sep-2018/total-expense-ratio-ter-of-mutual-fund-schemes_40295.html | TER slabs and limits |
| 13 | Groww Capital Gains Statement Guide | https://groww.in/blog/capital-gain-statement | How to download capital gains statement |
| 14 | CAMS Consolidated Account Statement | https://www.camsonline.com/Investors/Statements/ConsolidatedAccountStatement | Downloading CAS from CAMS |
| 15 | KFintech Consolidated Statement | https://mfs.kfintech.com/investor/General/ConsolidatedAccountStatement | Downloading CAS from KFintech |
| 16 | Groww MF Taxation Guide | https://groww.in/blog/mutual-fund-taxation | Tax on MF redemption, LTCG/STCG |
| 17 | AMFI Section 80C Tax Benefit Guide | https://www.amfiindia.com/investor-corner/knowledge-center/tax-benefits.html | ELSS 80C deduction up to ₹1.5 lakh |
| 18 | AMFI Investor Education — Exit Load | https://www.amfiindia.com/investor-corner/knowledge-center/exit-load.html | Exit load definition and rules |
| 19 | Groww SID/KIM Documents | https://groww.in/mutual-funds/documents | Scheme Information Documents |
| 20 | NSE India — Nifty Total Market Index | https://www.nseindia.com/products-services/indices-nifty-total-market-index | Benchmark index factsheet |

---

**Notes:**
- All URLs verified as public and accessible as of May 2025
- No paywalled, login-required, or third-party blog sources used
- Expense ratios are approximate and subject to change — always verify on Groww.in or AMFI
